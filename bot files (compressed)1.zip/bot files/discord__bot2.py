import discord
from discord.ext import commands
import gspread
from oauth2client.service_account import ServiceAccountCredentials


intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)


scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name("credentials.json", scope)
client = gspread.authorize(creds)
sheet = client.open("Flight Log").sheet1 

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user}")


@bot.command()
async def logflight(ctx, departure: str, arrival: str, flight_time: str, aircraft: str):
    """Logs a flight to the Google Sheet"""
    user = ctx.author.name  

    
    sheet.append_row([user, departure, arrival, flight_time, aircraft])

    await ctx.send(f"Flight logged! {user} flew from {departure} to {arrival} in {aircraft}, total flight time: {flight_time}.")


bot.run("MTM0Mjk0Mjk3OTQwODY1ODQ1Mw.GONKkC.t9uitXJdnLsek12mzFfIEHOaM2j7KnYyggD0V0")
